﻿using System;
using System.Collections.Generic;

public class PipeTransportJob
{
    public Guid JobId;
    public Guid PipeGraphId;

    public Vector3i SourceMachinePos;
    public Vector3i TargetStoragePos;

    public string ItemName;
    public int ItemCount;

    public readonly List<Vector3i> RoutePipePositions = new List<Vector3i>();

    public ulong StartWorldTime;
    public ulong ArrivalWorldTime;

    public bool IsComplete;
    public bool IsFailed;

    public PipeTransportJob()
    {
        JobId = Guid.NewGuid();
    }

    public PipeTransportJob(
        Guid pipeGraphId,
        Vector3i sourceMachinePos,
        Vector3i targetStoragePos,
        string itemName,
        int itemCount,
        IEnumerable<Vector3i> routePipePositions,
        ulong startWorldTime,
        ulong arrivalWorldTime)
    {
        JobId = Guid.NewGuid();
        PipeGraphId = pipeGraphId;
        SourceMachinePos = sourceMachinePos;
        TargetStoragePos = targetStoragePos;
        ItemName = itemName ?? string.Empty;
        ItemCount = itemCount;
        StartWorldTime = startWorldTime;
        ArrivalWorldTime = arrivalWorldTime;

        if (routePipePositions != null)
            RoutePipePositions.AddRange(routePipePositions);
    }

    public bool HasValidGraphId()
    {
        return PipeGraphId != Guid.Empty;
    }

    public bool HasValidItem()
    {
        return !string.IsNullOrEmpty(ItemName) && ItemCount > 0;
    }

    public bool HasRoute()
    {
        return RoutePipePositions.Count > 0;
    }

    public bool IsReadyToArrive(ulong worldTime)
    {
        return !IsComplete && !IsFailed && worldTime >= ArrivalWorldTime;
    }

    public bool UsesPipe(Vector3i pipePos)
    {
        return RoutePipePositions.Contains(pipePos);
    }

    public override string ToString()
    {
        return $"JobId={JobId} PipeGraphId={PipeGraphId} Source={SourceMachinePos} Target={TargetStoragePos} Item={ItemName} Count={ItemCount} RouteLen={RoutePipePositions.Count} Start={StartWorldTime} Arrival={ArrivalWorldTime} Complete={IsComplete} Failed={IsFailed}";
    }
}